# LUDUS Website Deployment Guide

## Introduction
This guide provides instructions for deploying the LUDUS website on various free hosting platforms. The website is a static HTML/CSS/JavaScript site that can be hosted on any static web hosting service.

## Deployment Options

### Option 1: GitHub Pages (Recommended)
GitHub Pages is a free hosting service that's perfect for static websites like LUDUS.

1. **Create a GitHub account** (if you don't have one already) at [github.com](https://github.com)
2. **Create a new repository**
   - Name it `ludus-website` or any name you prefer
   - Make it public
3. **Upload the website files**
   - Click on "uploading an existing file" on the repository page
   - Drag and drop all files from the `website` folder
   - Commit the changes
4. **Enable GitHub Pages**
   - Go to repository Settings > Pages
   - Under "Source", select "main" branch
   - Click Save
5. **Access your website**
   - Your site will be available at `https://[your-username].github.io/ludus-website/`

### Option 2: Netlify
Netlify offers free hosting with additional features like form handling.

1. **Create a Netlify account** at [netlify.com](https://netlify.com)
2. **Deploy your site**
   - Click "New site from upload"
   - Drag and drop the `website` folder
   - Wait for deployment to complete
3. **Access your website**
   - Netlify will provide a random URL (e.g., `random-name-123456.netlify.app`)
   - You can set a custom domain in the site settings

### Option 3: Vercel
Vercel is another excellent option for static site hosting.

1. **Create a Vercel account** at [vercel.com](https://vercel.com)
2. **Deploy your site**
   - Click "New Project"
   - Import from your local files (upload the `website` folder)
   - Follow the deployment steps
3. **Access your website**
   - Vercel will provide a URL like `ludus-website.vercel.app`

### Option 4: Cloudflare Pages
Cloudflare Pages offers free static site hosting with Cloudflare's CDN.

1. **Create a Cloudflare account** at [cloudflare.com](https://cloudflare.com)
2. **Go to Pages** in the dashboard
3. **Create a new project**
   - Upload your website files from the `website` folder
   - Configure build settings (not needed for this static site)
   - Deploy
4. **Access your website**
   - Your site will be available at a Cloudflare Pages URL

## Customizing Your Website

### Changing the Logo
- Replace the logo files in the `images` folder with your own versions
- Make sure to keep the same filenames or update the references in the HTML files

### Updating Content
- Edit the HTML files directly to update text content
- Modify the CSS in the `css` folder to change styling

## Troubleshooting

### Website Not Loading
- Ensure all files were uploaded correctly
- Check that the file structure was maintained during upload
- Verify that the hosting service has completed the deployment process

### Images Not Displaying
- Confirm that image paths in HTML files match the actual file locations
- Ensure all image files were included in the upload

## Need Help?
If you encounter any issues with deployment, most hosting providers offer comprehensive documentation and support:
- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [Netlify Documentation](https://docs.netlify.com/)
- [Vercel Documentation](https://vercel.com/docs)
- [Cloudflare Pages Documentation](https://developers.cloudflare.com/pages/)
