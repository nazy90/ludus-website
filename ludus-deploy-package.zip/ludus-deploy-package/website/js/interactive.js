// Additional JavaScript for interactive elements

document.addEventListener('DOMContentLoaded', function() {
    // Back to top button functionality
    const backToTopButton = document.createElement('a');
    backToTopButton.href = '#';
    backToTopButton.className = 'back-to-top';
    backToTopButton.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 15l-6-6-6 6"/></svg>';
    document.body.appendChild(backToTopButton);

    // Show/hide back to top button based on scroll position
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            backToTopButton.classList.add('visible');
        } else {
            backToTopButton.classList.remove('visible');
        }
    });

    // Smooth scroll to top when button is clicked
    backToTopButton.addEventListener('click', function(e) {
        e.preventDefault();
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });

    // Add link to CSS file
    const interactiveStylesheet = document.createElement('link');
    interactiveStylesheet.rel = 'stylesheet';
    interactiveStylesheet.href = 'css/interactive.css';
    document.head.appendChild(interactiveStylesheet);

    // Initialize any UI comparison sliders if they exist
    const comparisonSliders = document.querySelectorAll('.comparison-slider');
    if (comparisonSliders.length > 0) {
        comparisonSliders.forEach(slider => {
            // Slider initialization code would go here
            console.log('Slider initialized');
        });
    }

    // Add logo to header if it exists
    const logoElement = document.querySelector('.logo');
    if (logoElement) {
        const logoImg = document.createElement('img');
        logoImg.src = 'images/logo.svg';
        logoImg.alt = 'LUDUS Logo';
        logoImg.style.width = '40px';
        logoImg.style.marginRight = '10px';
        
        const logoTitle = logoElement.querySelector('h1');
        if (logoTitle) {
            logoTitle.parentNode.insertBefore(logoImg, logoTitle);
        }
    }
});
