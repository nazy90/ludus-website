// Main JavaScript file for LUDUS Analysis Website

document.addEventListener('DOMContentLoaded', function() {
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add active class to current navigation item
    const currentPage = window.location.pathname.split('/').pop();
    document.querySelectorAll('nav a').forEach(link => {
        if (link.getAttribute('href') === currentPage) {
            link.classList.add('active');
        }
    });

    // Mobile navigation toggle (if needed in the future)
    // const navToggle = document.querySelector('.nav-toggle');
    // const navMenu = document.querySelector('nav ul');
    // if (navToggle) {
    //     navToggle.addEventListener('click', () => {
    //         navMenu.classList.toggle('show');
    //     });
    // }
});
